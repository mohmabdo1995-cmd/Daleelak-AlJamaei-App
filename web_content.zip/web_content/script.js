/* =========================================================================
   1. NAVIGATION LOGIC
   ========================================================================= */
function navigateTo(sectionId) {
    // Hide all sections
    const sections = document.querySelectorAll('.view-section');
    sections.forEach(section => {
        section.classList.remove('active');
    });

    // Show the targeted section
    const targetSection = document.getElementById(sectionId);
    if (targetSection) {
        targetSection.classList.add('active');
        window.scrollTo(0, 0); // Scroll to top
    }
}

/* =========================================================================
   2. STUDY RESOURCES DATA & FILTERING
   ========================================================================= */
const resourcesData = [
    { id: 1, title: 'ملخص برمجة C++ (الفصل الأول)', type: 'ملخص pdf', icon: 'fa-file-pdf', category: 'pdf', link: '#' },
    { id: 2, title: 'شرح هياكل البيانات (فيديو)', type: 'فيديو', icon: 'fa-video', category: 'video', link: '#' },
    { id: 3, title: 'أساسيات تصميم الويب - كورس كامل', type: 'رابط خارجي', icon: 'fa-link', category: 'link', link: '#' },
    { id: 4, title: 'شيت الرياضيات المتقطعة رقم 1', type: 'ملف تفاعلي', icon: 'fa-file-word', category: 'pdf', link: '#' },
    { id: 5, title: 'مراجعة ليلة الامتحان - ذكاء اصطناعي', type: 'ملخص pdf', icon: 'fa-file-pdf', category: 'pdf', link: '#' },
    { id: 6, title: 'مقدمة في قواعد البيانات (فيديو 1)', type: 'فيديو', icon: 'fa-video', category: 'video', link: '#' }
];

const resourcesGrid = document.getElementById('resources-grid');
const searchInput = document.getElementById('resource-search');

function renderResources(data) {
    resourcesGrid.innerHTML = ''; // Clear current
    
    if (data.length === 0) {
        resourcesGrid.innerHTML = '<p style="grid-column: 1/-1; text-align: center; color: var(--text-muted);">عذراً، لم نجد نتائج مطابقة لبحثك.</p>';
        return;
    }

    data.forEach(item => {
        const card = document.createElement('div');
        card.className = 'resource-card';
        
        // Define color class based on category for styling
        const typeClass = item.category === 'video' ? 'video' : (item.category === 'link' ? 'link' : '');

        card.innerHTML = `
            <span class="resource-type ${typeClass}"><i class="fa-solid ${item.icon}"></i> ${item.type}</span>
            <h3 class="resource-title">${item.title}</h3>
            <a href="${item.link}" class="btn btn-outline" target="_blank">عرض المصدر</a>
        `;
        resourcesGrid.appendChild(card);
    });
}

// Initial render
renderResources(resourcesData);

// Search Feature
searchInput.addEventListener('input', (e) => {
    const searchTerm = e.target.value.toLowerCase();
    const filtered = resourcesData.filter(item => 
        item.title.toLowerCase().includes(searchTerm) || 
        item.type.toLowerCase().includes(searchTerm)
    );
    renderResources(filtered);
});

/* =========================================================================
   3. ORGANIZATION (To-Do List using LocalStorage)
   ========================================================================= */
let tasks = JSON.parse(localStorage.getItem('university_tasks')) || [];

const taskInput = document.getElementById('task-input');
const taskTime = document.getElementById('task-time');
const taskList = document.getElementById('task-list');
let currentFilter = 'all';

function saveTasks() {
    localStorage.setItem('university_tasks', JSON.stringify(tasks));
}

function renderTasks() {
    taskList.innerHTML = '';
    
    // Apply filter
    let filteredTasks = tasks;
    if (currentFilter === 'pending') {
        filteredTasks = tasks.filter(t => !t.completed);
    } else if (currentFilter === 'completed') {
        filteredTasks = tasks.filter(t => t.completed);
    }

    if (filteredTasks.length === 0) {
        taskList.innerHTML = `<p style="text-align: center; color: var(--text-muted); padding: 1rem;">لا توجد مهام حالياً في هذا التصنيف.</p>`;
        return;
    }

    filteredTasks.forEach(task => {
        const li = document.createElement('li');
        li.className = `task-item ${task.completed ? 'completed' : ''}`;
        
        li.innerHTML = `
            <div class="task-content" onclick="toggleTask(${task.id})">
                <div class="task-checkbox"></div>
                <span class="task-text">${task.text}</span>
                ${task.time ? `<span class="task-time-badge"><i class="fa-regular fa-clock"></i> ${task.time}</span>` : ''}
            </div>
            <div class="task-actions" onclick="deleteTask(${task.id})">
                <i class="fa-solid fa-trash"></i>
            </div>
        `;
        taskList.appendChild(li);
    });
}

function addTask() {
    const text = taskInput.value.trim();
    const time = taskTime.value;
    
    if (text !== '') {
        const newTask = {
            id: Date.now(),
            text: text,
            time: time,
            completed: false
        };
        tasks.push(newTask);
        saveTasks();
        renderTasks();
        
        // Clear inputs
        taskInput.value = '';
        taskTime.value = '';
        
        // Show alert briefly
        alert("تمت إضافة المهمة بنجاح!");
    } else {
        alert("الرجاء كتابة تفاصيل المهمة قبل الإضافة.");
    }
}

// Allow Enter key to submit
taskInput.addEventListener('keypress', function (e) {
    if (e.key === 'Enter') {
        addTask();
    }
});

function toggleTask(id) {
    tasks = tasks.map(task => {
        if (task.id === id) {
            return { ...task, completed: !task.completed };
        }
        return task;
    });
    saveTasks();
    renderTasks();
}

function deleteTask(id) {
    if (confirm('هل أنت متأكد من حذف هذه المهمة؟')) {
        tasks = tasks.filter(task => task.id !== id);
        saveTasks();
        renderTasks();
    }
}

function filterTasks(filterType) {
    currentFilter = filterType;
    
    // Update active UI
    document.querySelectorAll('.filter-btn').forEach(btn => {
        btn.classList.remove('active');
    });
    event.target.classList.add('active');
    
    renderTasks();
}

// Initial Render
renderTasks();

/* =========================================================================
   4. DYNAMIC MOTIVATIONAL MESSAGES
   ========================================================================= */
const motivationalMessages = [
    "البدايات دائما ما تكون صعبة، لكن الاستمرار يصنع المعجزات.",
    "النجاح لا يأتي إليك، بل أنت من يذهب إليه.",
    "كل ساعة دراسة إضافية تقربك خطوة نحو حلمك، استمر!",
    "تذكر دائماً لماذا بدأت.. ولا تتوقف حتى تصل.",
    "عقلك هو أقوى أداة تملكها، استثمر فيه من خلال التعلم.",
    "الألم المؤقت للدراسة أفضل بكثير من ألم الندم لاحقاً.",
    "أنت قادر على تحقيق ما تطمح إليه، فقط ثق بنفسك ونظم وقتك."
];

const bannerElement = document.getElementById('motivation-banner');

function changeMotivationalMessage() {
    const randomIndex = Math.floor(Math.random() * motivationalMessages.length);
    bannerElement.style.opacity = 0; // Fade out
    
    setTimeout(() => {
        bannerElement.innerHTML = `<p>"${motivationalMessages[randomIndex]}"</p>`;
        bannerElement.style.transition = 'opacity 0.5s ease';
        bannerElement.style.opacity = 1; // Fade in
    }, 500);
}

// Change message every 10 seconds
setInterval(changeMotivationalMessage, 10000);
// Also set one randomly on load
changeMotivationalMessage();
